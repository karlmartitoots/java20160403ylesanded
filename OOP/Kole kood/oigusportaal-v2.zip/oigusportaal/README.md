Original project:
https://github.com/Oigusportaal/oigusportaal

Problem description:
https://courses.cs.ut.ee/2013/tvp/fall/uploads/Main/Oigusportaal.pdf
