package main.details;

public class AttorneyDetails {
	
	String name;
	int bureauId;
	int attorneyId;
	String email;
	String picturePath;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBureauId() {
		return bureauId;
	}
	public void setBureauId(int bureauId) {
		this.bureauId = bureauId;
	}
	public int getAttorneyId() {
		return attorneyId;
	}
	public void setAttorneyId(int attorneyId) {
		this.attorneyId = attorneyId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPicturePath() {
		return picturePath;
	}
	public void setPicturePath(String picturePath) {
		this.picturePath = picturePath;
	}

}
