package main.details;

public class BureauDetails {
	
	public int bureauId;
	public int registryCode;
	public String bureauName;
	public String email;
	public String password;
	public int averagePrice;
	public String street;
	public int postalcode;
	public String image;
	public int active ;
	public String city;
	public String lastStoryParticipants;
	public String lastStoryPath;
	
	
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String fieldName;
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public int getBureauId() {
		return bureauId;
	}
	public void setBureauId(int bureauId) {
		this.bureauId = bureauId;
	}
	public int getRegistryCode() {
		return registryCode;
	}
	public void setRegistryCode(int registryCode) {
		this.registryCode = registryCode;
	}
	public String getBureauName() {
		return bureauName;
	}
	public void setBureauName(String bureauName) {
		this.bureauName = bureauName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAveragePrice() {
		return averagePrice;
	}
	public void setAveragePrice(int averagePrice) {
		this.averagePrice = averagePrice;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public int getPostalcode() {
		return postalcode;
	}
	public void setPostalcode(int postalcode) {
		this.postalcode = postalcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLastStoryParticipants() {
		return lastStoryParticipants;
	}
	public void setLastStoryParticipants(String lastStoryParticipants) {
		this.lastStoryParticipants = lastStoryParticipants;
	}
	public String getLastStoryPath() {
		return lastStoryPath;
	}
	public void setLastStoryPath(String lastStoryPath) {
		this.lastStoryPath = lastStoryPath;
	}

	
	
}
