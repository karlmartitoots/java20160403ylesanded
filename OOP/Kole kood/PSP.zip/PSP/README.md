Original project: 
https://github.com/OFFLlNE/PSP/

Problem description:
https://courses.cs.ut.ee/2015/tvp/fall/uploads/Main/Pit_Stop_Parking.pdf
