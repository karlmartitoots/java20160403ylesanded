package application;

import javafx.scene.control.ToggleButton;

class BlockButton extends ToggleButton {
        public int i;
}
